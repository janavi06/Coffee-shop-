﻿using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        int TotalCofeecost = 0;

        Start:
        Console.WriteLine( "Please select your cup size : Small - 1, Medium - 2, Large- 3");
        int Userchoice = int.Parse(Console.ReadLine());

        switch (Userchoice)

        {
            case 1: TotalCofeecost += 1; break;

            case 2: TotalCofeecost += 2;
                break;
                case 3: TotalCofeecost += 3; 
                break;

            default: Console.WriteLine("Your choice {0} is invalid", Userchoice);
                goto Start;
        }

    Decide:

        Console.WriteLine("Do you want Another coffee - Yes or No");
        String UserDecision = Console.ReadLine();

        switch (UserDecision.ToUpper())

        {
            case "Yes":
                goto Start;

                case "No";
                break;

            default: Console.WriteLine("Your Choice {0} is invalid", UserDecision);
                goto Decide;



        }



        Console.WriteLine("THANKYOU FOR SHOPPING WITH US");
        Console.WriteLine("BILL AMOUNT = {0}", TotalCofeecost);








    }
}